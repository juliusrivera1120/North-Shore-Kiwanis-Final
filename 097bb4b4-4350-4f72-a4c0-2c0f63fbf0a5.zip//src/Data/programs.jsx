[
  {
    id: 1,
    name: "Backpack & School Supply Drive",
    ageRange: "Elementary–High School",
    description:
      "Each August we collect and deliver backpacks, notebooks, and supplies so local students can start school prepared.",
  },
  {
    id: 2,
    name: "Community Clean-Up Days",
    ageRange: "All ages",
    description:
      "Club members, Key Club students, and families team up to pick up litter and beautify parks, beaches, and playgrounds.",
  },
  {
    id: 3,
    name: "Scholarship & Mentoring Program",
    ageRange: "High School Seniors",
    description:
      "North Shore Kiwanis awards scholarships and pairs students with mentors as they transition to college or career training.",
  },
];
