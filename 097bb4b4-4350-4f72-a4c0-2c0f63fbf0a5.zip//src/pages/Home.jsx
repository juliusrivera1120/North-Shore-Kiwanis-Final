import React from "react";
import hero from "../assets/hero.jpg";

function Home() {
  return (
    <section className="home">
      <section className="hero" aria-labelledby="hero-heading">
        <div className="hero-overlay">
          <h2 id="hero-heading">
            Serving the children of the world, starting on the North Shore.
          </h2>
          <p>
            North Shore Kiwanis is a volunteer-led Kiwanis club dedicated to
            improving the lives of children and families through hands-on
            service projects, fundraising, and partnerships with local schools.
          </p>

          {/* external link with title/target */}
          <a
            className="donate-btn"
            href="https://www.kiwanis.org/"
            title="Visit Kiwanis International in a new tab"
            target="_blank"
            rel="noreferrer"
          >
            Learn More About Kiwanis
          </a>
        </div>

        <picture>
          <source srcSet={hero} media="(min-width: 768px)" />
          <img
            src={hero}
            alt="Kiwanis volunteers working together at a community event"
            className="hero-img"
            width="1200"
            height="600"
          />
        </picture>
      </section>

      <section id="impact" className="impact-section">
        <h2>Our Community Impact</h2>
        <p>
          With the help of members, sponsors, and student leaders, North Shore
          Kiwanis supports service and leadership opportunities all year round.
        </p>

        <table className="impact-table">
          <thead>
            <tr>
              <th>Project</th>
              <th>People Reached</th>
              <th>Volunteer Hours</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Back-to-School Supply Drive</td>
              <td>250 students</td>
              <td>320</td>
            </tr>
            <tr>
              <td>Holiday Food Baskets</td>
              <td>140 families</td>
              <td>210</td>
            </tr>
            <tr>
              <td>Park &amp; Beach Clean-Ups</td>
              <td>8 public sites</td>
              <td>185</td>
            </tr>
          </tbody>
        </table>
      </section>
    </section>
  );
}

export default Home;
